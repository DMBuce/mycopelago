Readme for Netherending Ore Gen Configs 1.0.1

Extract the ore generation configs config\cofh\world\ of your modpack instance in order to use them.